# Random-numbers-game-with-JS

## English

A simple alerts game.
With Math.random() the program generates a random number. 
The purpose of the game is for the user to match that number. 
The game has 3 difficulties. 

### Easy difficulty: 

There is no limit of attempts. 

### Intermediate difficulty: 

The player has 5 attempts. 

### Difficult Difficulty: 

The player has 3 attempts.

#### You can see the explanation (spanish) on my YouTube channel:

https://bit.ly/3ekgKNy

## Spanish

Un simple juego de alerts. 
Con Math.random() el programa genera un número aleatorio.
La finalidad del juego es que el usuario acierte ese número.
El juego cuenta con 3 dificultades.

### Dificultad fácil:

No hay límite de intentos.

### Dificultad intermedia:

El jugador tiene 5 intentos.

### Dificultad difícil:

El jugador tiene 3 intentos.

#### Puedes ver la explicación en mi canal de YouTube:

https://bit.ly/3ekgKNy
