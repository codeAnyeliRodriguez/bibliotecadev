/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Números aleatorios en JavaScript.
*/

function generarFraccionAleatoria() {
  // Generar y retornar número entre 0 y 1
  // 0 inclusive. 1 no está incluido en los posibles resultados.
  return Math.random();
}

console.log(generarFraccionAleatoria());
console.log(generarFraccionAleatoria());
console.log(generarFraccionAleatoria());
console.log(generarFraccionAleatoria());

var numeroAleatorio = Math.random();
console.log(numeroAleatorio);
