/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Funciones flecha.
*/

// Función Anónima

const fecha = function() {
  return new Date();
};

// Función flecha

const fecha = () => new Date();
