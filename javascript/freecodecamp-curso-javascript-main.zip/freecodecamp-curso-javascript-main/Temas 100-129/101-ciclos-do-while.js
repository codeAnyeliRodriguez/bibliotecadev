/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Ciclos "do...while" en JavaScript.
*/

var x = 16;

do {
  console.log(x);
  x++;
} while (x < 10);

x = 16;

while (x < 10) {
  console.log(x);
  x++;
}
