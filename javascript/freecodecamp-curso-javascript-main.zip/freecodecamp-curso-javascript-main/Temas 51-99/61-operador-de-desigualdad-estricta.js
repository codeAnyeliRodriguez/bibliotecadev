/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Operador de desigualdad estricta.
*/

console.log(1 != "1");  // false
console.log(1 !== "1"); // true
