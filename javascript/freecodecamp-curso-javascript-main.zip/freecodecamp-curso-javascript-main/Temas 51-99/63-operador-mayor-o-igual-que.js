/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Operador "mayor o igual que" en JavaScript.
*/

// Mayor o igual que: >=

console.log(5 > 5);  // false
console.log(5 >= 5); // true
