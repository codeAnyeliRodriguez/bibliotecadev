/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Valor "undefined" retornado por una función.
*/

function sumar(a, b) {
  console.log(a + b);
}

// undefined porque no hay una sentencia return
console.log(sumar(a, b));
