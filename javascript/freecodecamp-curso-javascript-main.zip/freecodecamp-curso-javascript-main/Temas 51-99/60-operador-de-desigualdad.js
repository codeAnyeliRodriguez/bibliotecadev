/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Operador de desigualdad.
*/

console.log(9 != 6);  // true

console.log(9 != 9);  // false

console.log("JavaScript" != "JavaScript"); // false

console.log([1, 2, 3] != [1, 2, 3]); // true porque son distintos objetos.
