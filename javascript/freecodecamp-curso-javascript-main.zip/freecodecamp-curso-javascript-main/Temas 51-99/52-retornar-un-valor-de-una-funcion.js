/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Retornar un valor de una función.
*/

function sumar(a, b) {
  return a + b;
}

sumar(5, 3); // No se muestra nada en la consola

console.log(sumar(5, 3)); // Se muestra el valor retornado
