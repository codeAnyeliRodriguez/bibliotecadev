/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Ciclos "for": números impares.
*/

miArreglo = [];

for (var i = 1; i < 20; i += 2) {
  miArreglo.push(i);
}

console.log(miArreglo);
