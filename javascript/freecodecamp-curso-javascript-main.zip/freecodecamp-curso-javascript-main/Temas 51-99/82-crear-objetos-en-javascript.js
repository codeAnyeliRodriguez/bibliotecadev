/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Crear objetos en JavaScript.
*/

var miPerro = {
  "nombre": "Gino",
  "edad": 5,
  "peso": 6,
  "raza": "Beagle",
};

var miObjeto = {
  5: "cinco"
};