/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Operador de igualdad estricta.
*/

console.log(9 == 9);   // true
console.log(9 == "9"); // true

console.log(9 === 9);   // true
console.log(9 === "9"); // false
