/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Acceder a propiedades: notación de punto.
*/

var miPerro = {
  "nombre": "Gino",
  "edad": 5,
  "peso": 6,
  "raza": "Beagle",
};

console.log(miPerro.nombre);
console.log(miPerro.edad);
console.log(miPerro.peso);
console.log(miPerro.raza);
