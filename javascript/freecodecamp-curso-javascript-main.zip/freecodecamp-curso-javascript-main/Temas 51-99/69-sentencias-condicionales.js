/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Sentencias condicionales.
*/

if (true) {
  console.log("La condición es verdadera.");
}

// Condición verdadera (true).

var x = 5;

if (x > 2) {
  console.log("La condición es verdadera");
}

if (x > 2 && x < 10) {
  console.log("La condición es verdadera");
}

// Ejemplo

var estacion = "Invierno";

if (estacion == "Invierno") {
  console.log("¡Si! Me encanta el invierno.");
}

console.log("Después del condicional...");
