/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Acceder a propiedades: variables.
*/

var resultados = {
  1: "nora256",
  2: "gino577",
  3: "estef543",
  4: "kiara566"
};

var posicion = 4;

console.log(resultados[posicion]);
