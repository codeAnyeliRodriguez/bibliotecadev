/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Cláusula "else" en sentencias condicionales.
*/

if (false) {
  console.log("La condición es verdadera.");
} else {
  console.log("La condición es falsa.");
}

// Ejemplo

var x = 5;

if (x < 2) {
  console.log("La condición es verdadera.");
} else {
  console.log("La condición es falsa.");
}

// Ejemplo

var estacion = "Invierno";

if (estacion === "Verano") {
  console.log("Comenzó el verano. Ya podemos ir a la playa.");
} else {
  console.log("Ya quiero que llegue el verano para poder ir a la playa");
}
