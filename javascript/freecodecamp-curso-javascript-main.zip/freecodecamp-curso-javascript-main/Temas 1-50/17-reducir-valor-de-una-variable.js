/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Reducir el valor de una variable con JavaScript.
*/

var númeroDeEstudiantes = 256;
console.log(númeroDeEstudiantes);

númeroDeEstudiantes = númeroDeEstudiantes - 1;
console.log(númeroDeEstudiantes);

númeroDeEstudiantes--;
console.log(númeroDeEstudiantes);
