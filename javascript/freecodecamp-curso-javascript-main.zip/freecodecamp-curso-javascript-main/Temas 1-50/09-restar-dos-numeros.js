/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Restar dos números en JavaScript.
*/

var resta = 15 - 5; // Positivo
console.log(resta);

resta = 5 - 15; // Negativo
console.log(resta);

resta = 15 - 15; // Cero
console.log(resta);
