/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Dividir dos números decimales en JavaScript.
*/

var cociente = 5.0 / 2.0;
console.log(cociente);

cociente = 2.3 / 6.7;
console.log(cociente);

cociente = 4.2 / 0.0;
console.log(cociente);
