/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Calcular el resto de una división en JavaScript.
*/

var resto = 15 % 5;
console.log(resto);

resto = 5 % 1;
console.log(resto);

resto = 5 % 2;
console.log(resto);

resto = 5 % 3;
console.log(resto);

resto = 5 % 4;
console.log(resto);

resto = 5 % 5;
console.log(resto);
