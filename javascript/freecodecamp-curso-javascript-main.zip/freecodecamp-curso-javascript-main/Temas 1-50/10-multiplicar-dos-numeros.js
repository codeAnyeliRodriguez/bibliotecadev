/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Multiplicar dos números con JavaScript.
*/

var producto = 5 * 3;
console.log(producto);

producto = 9 * 0;
console.log(producto);

producto = -5 * 6;
console.log(producto);

producto = 5 * -6;
console.log(producto);

producto = -5 * -6;
console.log(producto);
