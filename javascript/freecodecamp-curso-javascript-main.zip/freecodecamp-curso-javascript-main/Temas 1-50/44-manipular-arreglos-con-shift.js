/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Manipular arreglos con .shift().
*/

var estaciones = ["Invierno", "Otoño", "Primavera"]; 

estaciones.shift();  // Remover primer elemento del arreglo

console.log(estaciones);
