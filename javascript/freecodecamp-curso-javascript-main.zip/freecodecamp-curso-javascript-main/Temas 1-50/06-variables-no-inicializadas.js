/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Variables no inicializadas.
*/

var a;
var b;

console.log(a); 
a = 56;          
console.log(a);
