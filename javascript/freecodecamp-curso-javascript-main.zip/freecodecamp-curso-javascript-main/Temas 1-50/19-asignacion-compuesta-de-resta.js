/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Asignación compuesta de resta.
*/

var b = 23;

b = b - 3;
console.log(b);

b -= 3;     
console.log(b);

// Ejemplo

var totalDeuda = 2446;

console.log(totalDeuda);
totalDeuda -= 345;
console.log(totalDeuda);
