/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Manipular arreglos con .unshift().
*/

var estaciones = ["Invierno", "Otoño", "Primavera"]; 

estaciones.unshift("Verano");   // Agregar al principio del arreglo

console.log(estaciones);
