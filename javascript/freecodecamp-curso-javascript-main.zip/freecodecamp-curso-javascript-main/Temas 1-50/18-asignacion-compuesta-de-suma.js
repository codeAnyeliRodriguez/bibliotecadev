/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Asignación compuesta de suma.
*/

var a = 23;

a = a + 5;
console.log(a);

a += 5;     
console.log(a);

var totalVentas = 13567.34;
console.log(totalVentas);

totalVentas += 345.67;
console.log(totalVentas);
