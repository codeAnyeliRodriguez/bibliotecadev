/*
Curso de freeCodeCamp: Aprende JavaScript desde Cero - Curso Completo
Creado por: Estefania Cassingena Navone (@EstefaniaCassN)
Tema: Notación de Corchetes: Primer Carácter.
*/

var lenguajeDeProgramación = "JavaScript";

/*
Cadena:   J a v a S c r i p t
Índices:  0 1 2 3 4 5 6 7 8 9
*/

console.log(lenguajeDeProgramación[0]);
