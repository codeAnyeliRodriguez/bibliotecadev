/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Inicializar variables en JavaScript.
*/

var x = 9;

var miIdioma = "Español";
