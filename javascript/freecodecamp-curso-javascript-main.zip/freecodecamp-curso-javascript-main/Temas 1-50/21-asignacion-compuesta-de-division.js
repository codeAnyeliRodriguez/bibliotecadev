/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Asignación compuesta de división.
*/

var d = 39;

d = d / 3;
console.log(d);

d /= 3;   
console.log(d);

// Ejemplo

var salario = 45000;

console.log(salario);
salario /= 2;
console.log(salario); 
