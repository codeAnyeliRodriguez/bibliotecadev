/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Manipular arreglos con .push().
*/

var estaciones = ["Invierno", "Otoño", "Primavera"]; // Orden alfabético

console.log(estaciones);
estaciones.push("Verano");  // Agregar al final del arreglo
console.log(estaciones);
