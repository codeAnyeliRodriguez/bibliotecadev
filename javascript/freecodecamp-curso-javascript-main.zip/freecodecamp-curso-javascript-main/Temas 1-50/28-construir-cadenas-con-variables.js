/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Construir cadenas con variables.
*/

var verbo = "programar"

var mensaje = "Estoy aprendiendo a " + verbo + " con freeCodeCamp";

console.log(mensaje);
