/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Longitud de una cadena de caracteres.
*/

var miCadena;

miCadena = "A";
console.log(miCadena.length);

miCadena = "AB";
console.log(miCadena.length);

var lenguajeDeProgramación = "JavaScript";
console.log(lenguajeDeProgramación.length);

var mensaje = "¡Estoy aprendiendo a programar!";
console.log(mensaje.length);

var mensaje = "Estoy aprendiendo a programar";
console.log(mensaje.length);

var mensaje = "Estoy aprendiendo a programar @#&*";
console.log(mensaje.length);
