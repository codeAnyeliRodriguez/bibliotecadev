/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Sumar dos números en JavaScript.
*/

var suma = 7 + 12;

console.log(suma);
