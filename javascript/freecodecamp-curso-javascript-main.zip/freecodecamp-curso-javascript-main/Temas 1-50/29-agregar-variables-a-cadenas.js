/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Agregar variables a cadenas.
*/

var mensajeCompleto = "Estoy aprendiendo a programar ";
var parteFinal = "con freeCodeCamp";

console.log(mensajeCompleto);
mensajeCompleto += parteFinal;
console.log(mensajeCompleto);
