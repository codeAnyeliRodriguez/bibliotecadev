/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Manipular arreglos con .pop().
*/

var estaciones;

estaciones = ["Invierno", "Otoño", "Primavera", "Verano"];

estacion = estaciones.pop();

console.log(estaciones);
console.log(estacion);
