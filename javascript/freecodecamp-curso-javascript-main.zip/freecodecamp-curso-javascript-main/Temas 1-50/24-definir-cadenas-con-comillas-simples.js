/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Definir cadenas con comillas simples.
*/

var miMeta;

// mensaje = "Aprender a programar con "freeCodeCamp""; // Error

miMeta = "Aprender a programar con \"freeCodeCamp\""; // Opción previa

// Alternativa más concisa: usar otro tipo de comillas.

miMeta = 'Aprender a programar con "freeCodeCamp"';

miMeta = "Aprender a programar con 'freeCodeCamp'";

console.log(miMeta);
