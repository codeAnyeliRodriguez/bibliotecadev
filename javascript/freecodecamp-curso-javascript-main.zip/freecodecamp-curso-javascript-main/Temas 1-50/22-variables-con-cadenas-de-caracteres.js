/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Variables con cadena de caracteres.
*/

var nombre = "Alan";

// Variaciones de la cadena de caracteres
var nombre = "A lan";
var nombre = "A&*$%^&#@@lan";
var nombre = "Alan34534_+-";

// Ejemplo

var apellido = "Turing";
