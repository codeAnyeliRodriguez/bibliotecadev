/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Multiplicar dos números decimales con JavaScript.
*/

var producto = 3.4 * 10.4;
console.log(producto);

producto = 2.4 * 4;
console.log(producto);

producto = 6 * 8.9;
console.log(producto);

producto = 3.6 * 0;
console.log(producto);

producto = -5.7 * 3.4;
console.log(producto);
