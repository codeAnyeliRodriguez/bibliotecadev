/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Asignación compuesta de multiplicación.
*/

var c = 23;

c = c * 2;
console.log(c);

c *= 2;   
console.log(c);

// Ejemplo

var salario = 45000;
console.log(salario);

salario *= 5;
console.log(salario); 
