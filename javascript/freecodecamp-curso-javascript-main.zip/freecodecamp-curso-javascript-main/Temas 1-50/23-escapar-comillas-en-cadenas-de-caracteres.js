/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Escapar comillas en cadenas de caracteres.
*/

// var miCadena = "Soy una cadena de caracteres "con comillas""; // Error

var miCadena = "Soy una cadena de caracteres \"con comillas\"";
console.log(miCadena);
