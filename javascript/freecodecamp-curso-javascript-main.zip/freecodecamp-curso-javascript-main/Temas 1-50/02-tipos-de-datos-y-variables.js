/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Tipos de Datos y Variables en JavaScript.
*/

/* Tipos de Datos:
undefined, null, boolean, string, symbol, number, y object.
*/

var miVariable = "freeCodeCamp";

console.log(miVariable);

// Cambiar el valor de la variable
miVariable = 16;

miVariable = true;

miVariable = false;

// Asignar nombre descriptivo a la variable
var miNombre = "Estefania";
