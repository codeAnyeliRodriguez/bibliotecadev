/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Asignar el valor de una variable a otra variable.
*/

// Opción 1

var a = 5;
var b = a;

console.log(a);
console.log(b);

// Opción 2

var a = 5;
var b;

b = a;

console.log(a);
console.log(b);
