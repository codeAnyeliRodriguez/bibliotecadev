/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Palabras en Blanco.
*/
var miSustantivo = "perro";
var miAdjetivo = "negro";
var miVerbo = "corrió";
var miAdverbio = "rápidamente";

/* Concatena las cadenas y crea una nueva cadena que muestre un mensaje. 
Puedes cambiar los valores de las variables.

Por ejemplo: El perro negro corrió rápidamente a la tienda.
             La bicicleta pequeña voló a tienda lentamente.
*/

var palabrasEnBlanco = "El" + miSustantivo + " " + miAdjetivo + " " + miVerbo + " " + miAdverbio + "a la tienda.";
console.log(palabrasEnBlanco);
