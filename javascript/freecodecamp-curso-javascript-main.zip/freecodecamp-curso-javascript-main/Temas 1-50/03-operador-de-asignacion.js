/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Operador de Asignación en JavaScript.
*/

var a;
var b = 2;

console.log(a); // undefined
console.log(b); // Tiene un valor

a = 10;
console.log(a);
