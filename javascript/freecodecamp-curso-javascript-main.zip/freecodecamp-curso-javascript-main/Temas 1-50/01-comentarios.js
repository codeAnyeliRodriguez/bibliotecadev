/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Comentarios en JavaScript.
*/

var x = 5; // Comentario de una línea

/* Este es un
comentario
de varias
líneas
*/
