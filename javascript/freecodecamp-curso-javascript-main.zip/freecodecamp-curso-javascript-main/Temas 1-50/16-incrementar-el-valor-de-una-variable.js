/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Incrementar el valor de una variable en JavaScript.
*/

var librosComprados = 105;
console.log(librosComprados); // Inicialmente

// Opción 1

librosComprados = librosComprados + 1;
console.log(librosComprados); 

// Opción 2

librosComprados++; 
console.log(librosComprados);
