/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Sensibilidad a mayúsculas y minúsculas en JavaScript.
*/

var miVariable = 5;

console.log(MIVARIABLE); // Error
console.log(Mivariable); // Error
console.log(MIvARIABLE); // Error
console.log(mivariable); // Error

console.log(miVariable);
