/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Dividir dos números en JavaScript.
*/

var cociente = 20 / 2;
console.log(cociente);

cociente = 17 / 31;
console.log(cociente);

cociente = 3 / 0;
console.log(cociente);
