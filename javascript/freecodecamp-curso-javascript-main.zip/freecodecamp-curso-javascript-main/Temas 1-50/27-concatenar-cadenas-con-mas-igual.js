/*
Curso de freeCodeCamp: "Aprende JavaScript - Curso Completo desde Cero".
Curso Creado por: Estefania Cassingena Navone (@EstefaniaCassN).
Tema: Concatenar cadenas con +=
*/

var mensajeCompleto = "Estoy aprendiendo a programar ";

console.log(mensajeCompleto);
mensajeCompleto += "con freeCodeCamp"; // Agregar la cadena al final de la existente.
console.log(mensajeCompleto);
