/*
* Curso de Node.js y Express.
* Creado para freeCodeCamp en Español.
* Por: Estefania Cassingena Navone. 
*/

const os = require('os');

console.log(os.type());

console.log(os.homedir());

console.log(os.uptime());

console.log(os.userInfo());