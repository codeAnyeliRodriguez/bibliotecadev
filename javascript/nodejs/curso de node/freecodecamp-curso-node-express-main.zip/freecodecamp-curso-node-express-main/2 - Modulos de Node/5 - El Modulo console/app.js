/*
* Curso de Node.js y Express.
* Creado para freeCodeCamp en Español.
* Por: Estefania Cassingena Navone. 
*/

console.log('¡Hola, Mundo!');

console.warn('Ocurrio un error...');

console.error('¡Ocurrio un error!');

// Pasando un objeto Error.
console.warn(new Error('¡Ocurrio un error!'));
console.error(new Error('¡Ocurrio un error!'));



