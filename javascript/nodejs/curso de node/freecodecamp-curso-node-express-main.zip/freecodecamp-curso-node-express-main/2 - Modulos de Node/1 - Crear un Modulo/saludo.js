/*
* Curso de Node.js y Express.
* Creado para freeCodeCamp en Español.
* Por: Estefania Cassingena Navone. 
*/

function saludar(nombre) {
  return `Hola ${nombre}`;
}