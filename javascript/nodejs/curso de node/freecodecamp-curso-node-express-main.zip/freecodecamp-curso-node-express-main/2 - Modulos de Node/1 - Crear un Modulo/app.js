/*
* Curso de Node.js y Express.
* Creado para freeCodeCamp en Español.
* Por: Estefania Cassingena Navone. 
*/

// Usar la función del módulo saludo.js
// genera un error porque no se ha incluido el módulo
// y no se ha exportado desde saludo.js.
console.log(saludar('freeCodeCamp'));