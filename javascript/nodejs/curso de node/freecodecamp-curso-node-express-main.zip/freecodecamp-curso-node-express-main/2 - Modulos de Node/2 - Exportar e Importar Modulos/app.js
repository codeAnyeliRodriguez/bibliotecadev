/*
* Curso de Node.js y Express.
* Creado para freeCodeCamp en Español.
* Por: Estefania Cassingena Navone. 
*/

const saludo = require('./saludo');

// Usar la función importada desde el módulo saludo.js.
console.log(saludo.saludar('freeCodeCamp'));