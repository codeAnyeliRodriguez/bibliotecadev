/*
* Curso de Node.js y Express.
* Creado para freeCodeCamp en Español.
* Por: Estefania Cassingena Navone. 
*/

const saludo = require('./saludo');

// Llamar a las funciones importadas desde modulo saludo.js.
console.log(saludo.saludar('freeCodeCamp'));
console.log(saludo.saludarHolaMundo());