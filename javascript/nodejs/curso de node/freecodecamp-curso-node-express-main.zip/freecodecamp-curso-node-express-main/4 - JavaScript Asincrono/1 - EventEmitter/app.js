/*
* Curso de Node.js y Express.
* Creado para freeCodeCamp en Español.
* Por: Estefania Cassingena Navone. 
*/

var EventEmitter = require('events');

console.log(EventEmitter);

console.log(typeof EventEmitter);